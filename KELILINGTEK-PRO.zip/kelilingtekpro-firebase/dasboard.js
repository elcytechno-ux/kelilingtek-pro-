db.collection("pesanan").orderBy("waktu", "desc").onSnapshot(snapshot => {
  const container = document.getElementById("pesananContainer");
  container.innerHTML = "";

  snapshot.forEach(doc => {
    const data = doc.data();
    const card = document.createElement("div");
    card.innerHTML = `
      <strong>${data.nama}</strong><br>
      ${data.alamat}<br>
      Layanan: ${data.layanan}<br>
      Status: ${data.status}<br><br>
      <button onclick="konfirmasiPesanan('${doc.id}', '${data.whatsapp}', '${data.nama}', '${data.layanan}')">✅ Konfirmasi</button>
      <button onclick="tolakPesanan('${doc.id}')">❌ Tolak</button>
      <hr>
    `;
    container.appendChild(card);
  });
});

function konfirmasiPesanan(id, wa, nama, layanan) {
  db.collection("pesanan").doc(id).update({
    status: "Dikonfirmasi"
  }).then(() => {
    alert("✅ Pesanan dikonfirmasi!");
    const pesan = `Halo ${nama}, pesanan Anda untuk ${layanan} telah dikonfirmasi. Teknisi akan segera menghubungi Anda. Terima kasih – KelilingTek Pro`;
    const linkWA = `https://wa.me/${wa}?text=${encodeURIComponent(pesan)}`;
    window.open(linkWA, "_blank");
  });
}

function tolakPesanan(id) {
  db.collection("pesanan").doc(id).update({
    status: "Ditolak"
  }).then(() => {
    alert("❌ Pesanan ditolak.");
  });
}
db.collection("tesKoneksi").add({
  waktu: new Date().toISOString(),
  pesan: "Halo dari KelilingTek Pro!"
})
.then(() => console.log("✅ Firestore aktif dan koneksi berhasil"))
.catch(err => console.error("❌ Gagal koneksi:", err));