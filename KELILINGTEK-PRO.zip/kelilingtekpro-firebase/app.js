fetch("assets/layanan.json")
  .then(res => res.json())
  .then(data => {
    const menu = document.getElementById("menuLayanan");
    const select = document.getElementById("pilihLayanan");

    data.forEach(item => {
      const card = document.createElement("div");
      card.innerHTML = `<strong>${item.nama}</strong><br>${item.deskripsi}<br><em>${item.harga}</em><hr>`;
      menu.appendChild(card);

      const option = document.createElement("option");
      option.value = item.nama;
      option.textContent = `${item.nama} - ${item.harga}`;
      select.appendChild(option);
    });
  });

document.getElementById("orderForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const nama = this.querySelector("input[placeholder='Nama Lengkap']").value;
  const alamat = this.querySelector("input[placeholder='Alamat Lengkap']").value;
  const whatsapp = this.querySelector("input[placeholder='Nomor WhatsApp']").value;
  const layanan = document.getElementById("pilihLayanan").value;

  const dataPesanan = {
    nama,
    alamat,
    whatsapp,
    layanan,
    waktu: new Date().toISOString(),
    status: "Menunggu Konfirmasi"
  };

  db.collection("pesanan").add(dataPesanan)
    .then(() => {
      alert("✅ Pesanan berhasil dikirim!");
      this.reset();

      const nomorAdmin = "6281390548590";
      const pesan = `📦 Pesanan Baru\nNama: ${nama}\nLayanan: ${layanan}\nAlamat: ${alamat}\nWA: ${whatsapp}`;
      const linkWA = `https://wa.me/${nomorAdmin}?text=${encodeURIComponent(pesan)}`;
      window.open(linkWA, "_blank");
    })
    .catch(err => {
      alert("❌ Gagal menyimpan pesanan: " + err.message);
    });
});