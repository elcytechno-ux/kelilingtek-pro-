<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyCc6hDZMitzd8BkCgm-guAsmWkOjdtEpo4",
    authDomain: "kelilingtek-pro.firebaseapp.com",
    projectId: "kelilingtek-pro",
    storageBucket: "kelilingtek-pro.firebasestorage.app",
    messagingSenderId: "804588528042",
    appId: "1:804588528042:web:b99b2b2b2df41077f44bd3"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
</script>