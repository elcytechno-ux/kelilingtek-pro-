db.collection("proyek").orderBy("waktu", "desc").limit(10).get()
  .then(snapshot => {
    const container = document.getElementById("fotoContainer");
    snapshot.forEach(doc => {
      const data = doc.data();
      const fotoList = data.foto || [];

      const card = document.createElement("div");
      card.className = "galeri-card";
      card.innerHTML = `
        <h3>${data.namaPelanggan}</h3>
        <p>${data.layanan}</p>
        <p>Status: ${data.status}</p>
        <div class="foto-wrapper">
          ${fotoList.map(url => `<img src="${url}" alt="Foto Proyek" />`).join("")}
        </div>
        <hr>
      `;
      container.appendChild(card);
    });
  });