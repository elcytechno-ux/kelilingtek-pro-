fetch("assets/layanan.json")
  .then(res => res.json())
  .then(data => {
    const menu = document.getElementById("menuLayanan");
    data.forEach(item => {
      const card = document.createElement("div");
      card.className = "layanan-card";
      card.innerHTML = `
        <h3>${item.nama}</h3>
        <p>${item.deskripsi}</p>
        <strong>${item.harga}</strong>
        <hr>
      `;
      menu.appendChild(card);
    });
  });