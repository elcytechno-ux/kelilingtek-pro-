firebase.auth().onAuthStateChanged(user => {
  if (!user) {
    alert("Silakan login terlebih dahulu.");
    window.location.href = "login.html";
  }
});

document.getElementById("logoutBtn").addEventListener("click", () => {
  firebase.auth().signOut().then(() => {
    window.location.href = "login.html";
  });
});
db.collection("pesanan").orderBy("waktu", "desc").onSnapshot(snapshot => {
  const container = document.getElementById("pesananContainer");
  container.innerHTML = "";

  snapshot.forEach(doc => {
    const data = doc.data();
    const card = document.createElement("div");
    card.innerHTML = `
      <strong>${data.nama}</strong><br>
      ${data.alamat}<br>
      Layanan: ${data.layanan}<br>
      Status: ${data.status}<br><br>
      <button onclick="konfirmasiPesanan('${doc.id}', '${data.whatsapp}', '${data.nama}', '${data.layanan}')">✅ Konfirmasi</button>
      <button onclick="tolakPesanan('${doc.id}')">❌ Tolak</button>
      <hr>
    `;
    container.appendChild(card);
  });
});
function konfirmasiPesanan(id, wa, nama, layanan) {
  db.collection("pesanan").doc(id).update({ status: "Dikonfirmasi" }).then(() => {
    const pesan = `Halo ${nama}, pesanan Anda untuk ${layanan} telah dikonfirmasi. Teknisi akan segera menghubungi Anda. Terima kasih – KelilingTek Pro`;
    window.open(`https://wa.me/${wa}?text=${encodeURIComponent(pesan)}`, "_blank");
  });
}

function tolakPesanan(id) {
  db.collection("pesanan").doc(id).update({ status: "Ditolak" }).then(() => {
    alert("❌ Pesanan ditolak.");
  });
}
db.collection("proyek").get().then(snapshot => {
  const total = snapshot.size;
  const selesai = snapshot.docs.filter(doc => doc.data().status === "Selesai").length;

  document.getElementById("statistikContainer").innerHTML = `
    <p>Total Proyek: ${total}</p>
    <p>Proyek Selesai: ${selesai}</p>
  `;
});

document.getElementById("filterStatus").addEventListener("change", function () {
  const status = this.value;
  let query = db.collection("pesanan");

  if (status !== "Semua") {
    query = query.where("status", "==", status);
  }

  query.orderBy("waktu", "desc").get().then(snapshot => {
    const container = document.getElementById("pesananContainer");
    container.innerHTML = "";

    snapshot.forEach(doc => {
      const data = doc.data();
      const card = document.createElement("div");
      card.innerHTML = `
        <strong>${data.nama}</strong><br>
        ${data.alamat}<br>
        Layanan: ${data.layanan}<br>
        Status: ${data.status}<br><br>
        <button onclick="konfirmasiPesanan('${doc.id}', '${data.whatsapp}', '${data.nama}', '${data.layanan}')">✅ Konfirmasi</button>
        <button onclick="tolakPesanan('${doc.id}')">❌ Tolak</button>
        <hr>
      `;
      container.appendChild(card);
    });
  });
});
function tampilkanStatistik() {
  const container = document.getElementById("statistikContainer");

  Promise.all([
    db.collection("pesanan").get(),
    db.collection("proyek").get()
  ]).then(([pesananSnapshot, proyekSnapshot]) => {
    const totalPesanan = pesananSnapshot.size;
    const dikonfirmasi = pesananSnapshot.docs.filter(doc => doc.data().status === "Dikonfirmasi").length;
    const ditolak = pesananSnapshot.docs.filter(doc => doc.data().status === "Ditolak").length;
    const totalProyek = proyekSnapshot.size;

    container.innerHTML = `
      <p>Total Pesanan: <strong>${totalPesanan}</strong></p>
      <p>Dikonfirmasi: <strong>${dikonfirmasi}</strong></p>
      <p>Ditolak: <strong>${ditolak}</strong></p>
      <p>Proyek Selesai (Upload Foto): <strong>${totalProyek}</strong></p>
    `;
  });
}

tampilkanStatistik();

card.innerHTML = `
  <strong>${data.nama}</strong><br>
  ${data.alamat}<br>
  Layanan: ${data.layanan}<br>
  Status: ${data.status}<br><br>
  ${data.linkMaps ? `<a href="${data.linkMaps}" target="_blank">📍 Lihat Lokasi</a><br>` : ""}
  <button onclick="konfirmasiPesanan('${doc.id}', '${data.whatsapp}', '${data.nama}', '${data.layanan}')">✅ Konfirmasi</button>
  <button onclick="tolakPesanan('${doc.id}')">❌ Tolak</button>
  <hr>
`;
document.getElementById("fotoProyek").addEventListener("change", function () {
  const preview = document.getElementById("previewFoto");
  preview.innerHTML = "";

  Array.from(this.files).forEach(file => {
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.createElement("img");
      img.src = e.target.result;
      img.className = "preview-img";
      preview.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
})
document.getElementById("fotoProyek").addEventListener("change", function () {
  const preview = document.getElementById("previewFoto");
  preview.innerHTML = "";
  fileList = [];

  Array.from(this.files).forEach((file, index) => {
    const isValidType = ["image/jpeg", "image/png"].includes(file.type);
    const isValidSize = file.size <= 2 * 1024 * 1024; // 2MB

    if (!isValidType || !isValidSize) {
      alert(`❌ File ${file.name} tidak valid. Hanya JPG/PNG dan maksimal 2MB.`);
      return;
    }

    fileList.push(file);

    const reader = new FileReader();
    reader.onload = function (e) {
      const wrapper = document.createElement("div");
      wrapper.className = "preview-item";

      const img = document.createElement("img");
      img.src = e.target.result;
      img.className = "preview-img";

      const btn = document.createElement("button");
      btn.textContent = "❌";
      btn.className = "hapus-btn";
      btn.onclick = () => {
        fileList.splice(index, 1);
        wrapper.remove();
      };

      wrapper.appendChild(img);
      wrapper.appendChild(btn);
      preview.appendChild(wrapper);
    };
    reader.readAsDataURL(file);
  });
});

